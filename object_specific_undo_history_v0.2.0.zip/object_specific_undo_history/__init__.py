# Object Specific Undo History: per-object undo history with a scrub bar in the 3D viewport header.
# Transforms + mesh shape (as deltas) + topology changes made in Edit Mode.

import json
import os
import time
import traceback

import bpy
import numpy as np
from bpy.app.handlers import persistent

# ---------------------------------------------------------------------------
# Storage (RAM only, cleared on file load)
# ---------------------------------------------------------------------------

class TopoStep:
    """A step where the vertex/edge/face count changed (extrude, subdivide, ...).
    Holds full copies of the mesh before and after, so it can be undone too."""
    __slots__ = ("old", "new")

    def __init__(self, old, new):
        self.old = old
        self.new = new

    def nbytes(self):
        return snapshot_nbytes(self.old) + snapshot_nbytes(self.new)


class History:
    """Steps are stored as small "what changed" deltas, not full mesh copies.
    mats[i]   = object transform at step i
    deltas[i] = going from step i-1 to i: None, (vert indices, old positions, new positions),
                or a TopoStep when the mesh topology changed
    pos       = full vertex positions at the current step (one copy per object)
    counts    = (verts, edges, faces) at the current step"""
    __slots__ = ("mats", "deltas", "index", "pos", "counts")

    def __init__(self):
        self.mats = []
        self.deltas = []
        self.index = -1
        self.pos = None
        self.counts = None

    def reset(self, m, pos, counts=None):
        self.mats = [m]
        self.deltas = [None]
        self.index = 0
        self.pos = pos
        self.counts = counts

    def nbytes(self):
        n = self.pos.nbytes if self.pos is not None else 0
        for d in self.deltas:
            if isinstance(d, TopoStep):
                n += d.nbytes()
            elif d is not None:
                n += d[0].nbytes + d[1].nbytes + d[2].nbytes
        return n


_hist = {}       # session_uid -> History
_names = {}      # session_uid -> last known object name
_dirty = {}      # session_uid -> time of last change
_geo = set()     # session_uids whose mesh shape (not just transform) changed
_frame_t = 0.0   # when the current frame change started
_scrub = None    # dict for pending slider scrubs
_settle = None   # (uid, time) sculpt refresh waiting for scrubbing to stop
_press = None    # uid of object whose paint/sculpt stroke is in progress
_watchers = set()  # window pointers with a running stroke watcher
_stop = False

STROKE_MODES = {'SCULPT', 'VERTEX_PAINT', 'WEIGHT_PAINT', 'TEXTURE_PAINT', 'SCULPT_CURVES'}


class _DefaultPrefs:
    max_steps = 200
    smart_ctrl_z = True
    save_history = True
    topo_max_verts = 100000
    idle_delay = 0.1
    sculpt_refresh = True
    bar_width = 14


def prefs():
    try:
        return bpy.context.preferences.addons[__package__].preferences
    except Exception:
        return _DefaultPrefs


def tracking(obj):
    return obj is not None and getattr(obj, "orw_track", True)


def get_obj(uid):
    name = _names.get(uid)
    obj = bpy.data.objects.get(name) if name else None
    if obj is not None and obj.session_uid == uid:
        return obj
    for ob in bpy.data.objects:  # renamed?
        if ob.session_uid == uid:
            _names[uid] = ob.name
            return ob
    return None


def get_hist(obj):
    """Find this object's history, re-linking it if Blender's undo gave the object a new id."""
    uid = obj.session_uid
    h = _hist.get(uid)
    if h is not None:
        return h
    for old_uid, name in list(_names.items()):
        if name == obj.name and old_uid in _hist and get_obj(old_uid) is None:
            _hist[uid] = _hist.pop(old_uid)
            _names.pop(old_uid, None)
            _names[uid] = obj.name
            if old_uid in _dirty:
                _dirty[uid] = _dirty.pop(old_uid)
            return _hist[uid]
    return None


def active_object():
    try:
        ob = bpy.context.view_layer.objects.active
        if ob is not None:
            return ob
    except Exception:
        pass
    try:
        return bpy.context.window_manager.windows[0].view_layer.objects.active
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Capture / record / restore
# ---------------------------------------------------------------------------

# Transforms are stored as the exact location/rotation/scale values (not a matrix),
# so restoring gives back identical numbers and doesn't look like a new change.
ROT_MODES = ('QUATERNION', 'XYZ', 'XZY', 'YXZ', 'YZX', 'ZXY', 'ZYX', 'AXIS_ANGLE')
XFORM_LEN = 18


def get_xform(obj):
    return (*obj.location, *obj.rotation_euler, *obj.rotation_quaternion,
            *obj.rotation_axis_angle, *obj.scale, float(ROT_MODES.index(obj.rotation_mode)))


def set_xform(obj, m):
    mode = ROT_MODES[int(m[17])]
    if obj.rotation_mode != mode:
        obj.rotation_mode = mode
    obj.location = m[0:3]
    obj.rotation_euler = m[3:6]
    obj.rotation_quaternion = m[6:10]
    obj.rotation_axis_angle = m[10:14]
    obj.scale = m[14:17]


def mesh_counts(me):
    return (len(me.vertices), len(me.edges), len(me.polygons))


ATTR_KEY = {'FLOAT': ("value", 1, np.float32), 'INT': ("value", 1, np.int32),
            'INT8': ("value", 1, np.int8), 'BOOLEAN': ("value", 1, bool),
            'FLOAT_VECTOR': ("vector", 3, np.float32), 'FLOAT2': ("vector", 2, np.float32),
            'INT32_2D': ("value", 2, np.int32), 'FLOAT_COLOR': ("color", 4, np.float32),
            'BYTE_COLOR': ("color", 4, np.float32), 'QUATERNION': ("value", 4, np.float32)}


def _get(coll, key, n, dtype):
    a = np.empty(n, dtype=dtype)
    coll.foreach_get(key, a)
    return a


def mesh_snapshot(me):
    """Full copy of a mesh's geometry and attributes (UVs, colours, creases...) as arrays."""
    nv, ne, nf = mesh_counts(me)
    nl = len(me.loops)
    snap = {"counts": (nv, ne, nf), "nl": nl,
            "co": _get(me.vertices, "co", nv * 3, np.float32),
            "edges": _get(me.edges, "vertices", ne * 2, np.int32),
            "loop_v": _get(me.loops, "vertex_index", nl, np.int32),
            "loop_e": _get(me.loops, "edge_index", nl, np.int32),
            "loop_start": _get(me.polygons, "loop_start", nf, np.int32),
            "attrs": [],
            "active_uv": me.uv_layers.active.name if me.uv_layers.active else None}
    for a in me.attributes:
        if a.is_internal or a.name == "position" or a.data_type not in ATTR_KEY:
            continue
        key, comps, dtype = ATTR_KEY[a.data_type]
        try:
            arr = _get(a.data, key, len(a.data) * comps, dtype)
        except Exception:
            continue
        snap["attrs"].append((a.name, a.domain, a.data_type, arr))
    return snap


def safe_snapshot(me, in_edit):
    if not in_edit:
        return mesh_snapshot(me)
    tmp = me.copy()
    try:
        return mesh_snapshot(tmp)
    finally:
        bpy.data.meshes.remove(tmp)


def snapshot_nbytes(snap):
    n = sum(snap[k].nbytes for k in ("co", "edges", "loop_v", "loop_e", "loop_start"))
    return n + sum(a[3].nbytes for a in snap["attrs"])


def apply_snapshot(me, snap):
    """Rebuild a mesh in place from a snapshot (object must not be in edit mode)."""
    nv, ne, nf = snap["counts"]
    keep = {a[0] for a in snap["attrs"]}
    me.clear_geometry()
    me.vertices.add(nv)
    me.vertices.foreach_set("co", snap["co"])
    me.edges.add(ne)
    me.edges.foreach_set("vertices", snap["edges"])
    me.loops.add(snap["nl"])
    me.loops.foreach_set("vertex_index", snap["loop_v"])
    me.loops.foreach_set("edge_index", snap["loop_e"])
    me.polygons.add(nf)
    me.polygons.foreach_set("loop_start", snap["loop_start"])
    for a in list(me.attributes):
        if not a.is_internal and a.name != "position" and a.name not in keep:
            try:
                me.attributes.remove(a)
            except Exception:
                pass
    for name, domain, dtype, arr in snap["attrs"]:
        a = me.attributes.get(name)
        if a is not None and (a.domain != domain or a.data_type != dtype):
            me.attributes.remove(a)
            a = None
        if a is None:
            a = me.attributes.new(name, dtype, domain)
        try:
            a.data.foreach_set(ATTR_KEY[dtype][0], arr)
        except Exception:
            traceback.print_exc()
    if snap["active_uv"] and snap["active_uv"] in me.uv_layers:
        me.uv_layers.active = me.uv_layers[snap["active_uv"]]
    me.update()


def topo_ok(obj):
    """Topology undo can't carry vertex group weights or shape keys, so those fall back to a reset."""
    return obj.type == 'MESH' and not obj.vertex_groups and obj.data.shape_keys is None


def read_pos(me):
    pos = np.empty(len(me.vertices) * 3, dtype=np.float32)
    me.vertices.foreach_get("co", pos)
    return pos.reshape(-1, 3)


def capture(obj, h=None, geo=True):
    """Returns (transform, positions or None, counts or None, TopoStep-before-snapshot or None).
    positions is None when only the transform changed (cheap path)."""
    m = get_xform(obj)
    if obj.type != 'MESH':
        return m, None, None, None
    me = obj.data
    if not geo and h is not None and h.pos is not None and obj.mode not in ('EDIT', 'SCULPT'):
        return m, None, None, None
    old_snap = None
    if obj.mode == 'EDIT':
        if h is not None and h.counts is not None and topo_ok(obj) \
                and h.counts[0] <= prefs().topo_max_verts:
            import bmesh
            bm = bmesh.from_edit_mesh(me)
            if (len(bm.verts), len(bm.edges), len(bm.faces)) != h.counts and mesh_counts(me) == h.counts:
                # The mesh datablock still holds the last recorded state until we sync it,
                # so grab it now to make the topology change undoable. In Edit Mode Python
                # can't read UVs etc. from it directly, so read them from a temporary copy.
                old_snap = safe_snapshot(me, True)
        obj.update_from_editmode()
    return m, read_pos(me), mesh_counts(me), old_snap


def _push(h, m, delta):
    del h.mats[h.index + 1:]    # a new change replaces the redo steps
    del h.deltas[h.index + 1:]
    h.mats.append(m)
    h.deltas.append(delta)
    over = len(h.mats) - max(2, prefs().max_steps)
    if over > 0:
        del h.mats[:over]
        del h.deltas[:over]
        h.deltas[0] = None
    h.index = len(h.mats) - 1


def linked_users(obj):
    """Other tracked objects sharing this object's mesh (linked duplicates, Alt+D)."""
    if obj.type != 'MESH' or obj.data.users < 2:
        return []
    out = []
    for uid, h in _hist.items():
        o = get_obj(uid)
        if o is not None and o != obj and o.type == 'MESH' and o.data == obj.data:
            out.append(h)
    return out


def sync_linked(obj, h):
    """After obj's shared mesh changed, update the other users' idea of the current shape
    so they don't record obj's edit as their own."""
    for h2 in linked_users(obj):
        if h2.pos is not None and h.pos is not None and h2.pos.shape == h.pos.shape:
            h2.pos[:] = h.pos
        else:
            h2.pos = None if h.pos is None else h.pos.copy()
            h2.deltas = [None] * len(h2.deltas)  # its old shape steps no longer fit
        h2.counts = h.counts


def record(obj, geo=None):
    """Add a new step if the object changed since its current step. Returns True if added."""
    if not tracking(obj):
        return False
    uid = obj.session_uid
    h = get_hist(obj)
    _names[uid] = obj.name
    _dirty.pop(uid, None)
    if geo is None:
        geo = uid in _geo
    _geo.discard(uid)
    m, pos, counts, old_snap = capture(obj, h, geo)

    if h is None or not h.mats:
        h = _hist[uid] = History()
        h.reset(m, pos, counts)
        redraw()
        return True

    delta = None
    if pos is not None:
        shared = obj.data.users > 1 and obj != active_object()
        if h.pos is None or pos.shape != h.pos.shape or counts != h.counts:
            if old_snap is not None and h.pos is not None and old_snap["co"].size == h.pos.size:
                delta = TopoStep(old_snap, safe_snapshot(obj.data, obj.mode == 'EDIT'))  # undoable topology change
                h.pos = pos
                h.counts = counts
            elif shared:
                h.pos, h.counts = pos, counts
            else:
                h.reset(m, pos, counts)  # remesh/Dyntopo etc: old shapes can't be restored
                sync_linked(obj, h)
                redraw()
                return True
        else:
            changed = np.flatnonzero((h.pos != pos).any(axis=1)).astype(np.int32)
            if changed.size:
                if shared:
                    h.pos[changed] = pos[changed]  # another user of this mesh made the edit
                else:
                    delta = (changed, h.pos[changed], pos[changed])
                    h.pos[changed] = pos[changed]
        if delta is not None:
            sync_linked(obj, h)

    cm = h.mats[h.index]
    if delta is None and cm == m:
        return False
    if cm == m:
        m = cm  # share data with previous step
    _push(h, m, delta)
    redraw()
    return True


def flush(obj):
    """Record any pending change right now (used before undo/scrub)."""
    if obj is not None and (obj.session_uid in _dirty or get_hist(obj) is None):
        record(obj)


def view3d_override():
    wm = bpy.context.window_manager
    for win in wm.windows:
        for area in win.screen.areas:
            if area.type == 'VIEW_3D':
                region = next((r for r in area.regions if r.type == 'WINDOW'), None)
                return {"window": win, "area": area, "region": region}
    return {}


def mode_set(mode):
    with bpy.context.temp_override(**view3d_override()):
        bpy.ops.object.mode_set(mode=mode)


def sculpt_refresh(obj):
    """Sculpt mode keeps its own copy of the mesh, so re-enter the mode to show restored data."""
    if obj.mode == 'SCULPT' and active_object() == obj:
        mode_set('OBJECT')
        mode_set('SCULPT')


def restore(obj, index, live=False):
    """Jump obj to a history step. live=True is the cheap path used while scrubbing."""
    global _settle
    h = get_hist(obj)
    if h is None or not h.mats:
        return "No history"
    index = max(0, min(index, len(h.mats) - 1))
    mesh = h.pos is not None and obj.type == 'MESH'
    if mesh and obj.mode != 'EDIT' and mesh_counts(obj.data) != h.counts:
        return "Mesh topology changed outside the history, can't restore"
    lo, hi = sorted((h.index, index))
    topo = mesh and any(isinstance(h.deltas[k], TopoStep) for k in range(lo + 1, hi + 1))
    if mesh and obj.mode == 'EDIT' and live:
        return None  # edit mode is applied once scrubbing stops

    set_xform(obj, h.mats[index])

    if mesh and index != h.index:
        mode = obj.mode
        if mode == 'EDIT' or (topo and mode != 'OBJECT'):
            mode_set('OBJECT')
        me = obj.data
        pos = h.pos
        i = h.index
        while i < index:          # forwards: apply "new" values
            i += 1
            d = h.deltas[i]
            if isinstance(d, TopoStep):
                apply_snapshot(me, d.new)
                pos = d.new["co"].reshape(-1, 3).copy()
            elif d is not None:
                pos[d[0]] = d[2]
        while i > index:          # backwards: apply "old" values
            d = h.deltas[i]
            if isinstance(d, TopoStep):
                apply_snapshot(me, d.old)
                pos = d.old["co"].reshape(-1, 3).copy()
            elif d is not None:
                pos[d[0]] = d[1]
            i -= 1
        h.pos = pos
        h.counts = mesh_counts(me)
        me.vertices.foreach_set("co", pos.ravel())
        me.update()
        sync_linked(obj, h)
        if obj.mode != mode:
            mode_set(mode)
        elif mode == 'SCULPT' and prefs().sculpt_refresh:
            if live:
                _settle = (obj.session_uid, time.monotonic())
            else:
                sculpt_refresh(obj)

    h.index = index
    _dirty.pop(obj.session_uid, None)
    _geo.discard(obj.session_uid)
    redraw()
    return None


def redraw():
    try:
        for win in bpy.context.window_manager.windows:
            for area in win.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Change detection (kept tiny so it adds no lag while brushing)
# ---------------------------------------------------------------------------

def _is_animated(ob):
    ad = ob.animation_data
    return ad is not None and (ad.action is not None or len(ad.drivers) > 0)


@persistent
def on_depsgraph(scene, depsgraph):
    try:
        scr = bpy.context.screen
        if scr is not None and scr.is_animation_playing:
            return
    except Exception:
        pass
    now = time.monotonic()
    act = active_object()
    # Meshes whose own data changed (an edit), as opposed to only being deformed by
    # an armature/modifier, which doesn't touch the stored shape.
    meshes = {u.id.original for u in depsgraph.updates
              if isinstance(u.id, bpy.types.Mesh) and u.is_updated_geometry}
    for u in depsgraph.updates:
        idb = u.id
        if isinstance(idb, bpy.types.Object):
            ob = idb.original
            if not (ob is act or ob.select_get()):
                continue
            geo = ob.type == 'MESH' and (ob.data in meshes or ob.mode in ('EDIT', 'SCULPT')) \
                and u.is_updated_geometry
            moved = u.is_updated_transform
            if geo:
                _geo.add(ob.session_uid)
            if geo or moved:
                _dirty[ob.session_uid] = now
                _names[ob.session_uid] = ob.name
    if act is not None and act.type == 'MESH' and act.data in meshes:
        _dirty[act.session_uid] = now
        _geo.add(act.session_uid)
        _names[act.session_uid] = act.name


@persistent
def on_frame_pre(*_args):
    global _frame_t
    _frame_t = time.monotonic()


@persistent
def on_frame_post(*_args):
    # Changes made by keyframes/drivers while the frame changed aren't edits: drop them.
    for uid, t in list(_dirty.items()):
        if t >= _frame_t:
            ob = get_obj(uid)
            if ob is not None and _is_animated(ob):
                _dirty.pop(uid, None)
                _geo.discard(uid)


@persistent
def on_load(*_args):
    global _scrub, _settle, _press
    _hist.clear()
    _names.clear()
    _dirty.clear()
    _geo.clear()
    _watchers.clear()  # modal watchers die on file load; tick() restarts them
    _scrub = None
    _settle = None
    _press = None
    try:
        load_history()
    except Exception:
        traceback.print_exc()


# ---------------------------------------------------------------------------
# Saving history next to the .blend (yourfile.blend.undohistory)
# ---------------------------------------------------------------------------

SIDECAR_EXT = ".undohistory"
SIDECAR_VERSION = 2


def sidecar_path():
    fp = bpy.data.filepath
    return fp + SIDECAR_EXT if fp else None


@persistent
def on_save_pre(*_args):
    # Record anything still waiting so the saved history matches the saved file.
    for uid in list(_dirty):
        obj = get_obj(uid)
        if obj is not None:
            try:
                record(obj)
            except Exception:
                traceback.print_exc()


@persistent
def on_save_post(*_args):
    if not prefs().save_history:
        return
    try:
        save_history()
    except Exception:
        traceback.print_exc()


def save_history():
    path = sidecar_path()
    if not path:
        return
    arrays = {}
    meta = {"version": SIDECAR_VERSION, "objects": []}
    i = 0
    for uid, h in _hist.items():
        obj = get_obj(uid)
        if obj is None or not h.mats:
            continue
        k = f"o{i}_"
        # Topology steps hold whole meshes and aren't saved; keep the stretch of steps
        # around the current one that doesn't cross one.
        start = 0
        for j in range(h.index, 0, -1):
            if isinstance(h.deltas[j], TopoStep):
                start = j
                break
        end = len(h.mats)
        for j in range(h.index + 1, len(h.mats)):
            if isinstance(h.deltas[j], TopoStep):
                end = j
                break
        deltas = [None] + list(h.deltas[start + 1:end])
        arrays[k + "mats"] = np.array(h.mats[start:end], dtype=np.float64)
        has_pos = h.pos is not None
        if has_pos:
            arrays[k + "pos"] = h.pos
            lens = np.array([-1 if d is None else len(d[0]) for d in deltas], dtype=np.int64)
            parts = [d for d in deltas if d is not None]
            arrays[k + "dlen"] = lens
            arrays[k + "didx"] = np.concatenate([d[0] for d in parts]) if parts else np.zeros(0, np.int32)
            arrays[k + "dold"] = np.concatenate([d[1] for d in parts]) if parts else np.zeros((0, 3), np.float32)
            arrays[k + "dnew"] = np.concatenate([d[2] for d in parts]) if parts else np.zeros((0, 3), np.float32)
        meta["objects"].append({"key": k, "name": obj.name, "index": h.index - start, "has_pos": has_pos})
        i += 1
    if not meta["objects"]:
        if os.path.exists(path):
            os.remove(path)  # nothing to keep, don't leave a stale history behind
        return
    arrays["meta"] = np.frombuffer(json.dumps(meta).encode("utf-8"), dtype=np.uint8)
    tmp = path + ".tmp"
    with open(tmp, "wb") as f:
        np.savez(f, **arrays)
    os.replace(tmp, path)  # only swap in a fully written file


def load_history():
    path = sidecar_path()
    if not path or not os.path.exists(path):
        return
    with np.load(path, allow_pickle=False) as data:
        meta = json.loads(bytes(data["meta"]).decode("utf-8"))
        if meta.get("version") != SIDECAR_VERSION:
            return
        for o in meta["objects"]:
            obj = bpy.data.objects.get(o["name"])
            if obj is None:
                continue
            k = o["key"]
            mats = [tuple(float(v) for v in row) for row in data[k + "mats"]]
            h = History()
            h.mats = mats
            h.index = min(int(o["index"]), len(mats) - 1)
            h.deltas = [None] * len(mats)
            if o["has_pos"]:
                if obj.type != 'MESH':
                    continue
                pos = np.array(data[k + "pos"], dtype=np.float32)
                if len(obj.data.vertices) != len(pos):
                    continue  # mesh changed outside the add-on, history no longer fits
                cur = np.empty(len(pos) * 3, dtype=np.float32)
                obj.data.vertices.foreach_get("co", cur)
                if not np.array_equal(cur.reshape(-1, 3), pos):
                    continue  # shape differs from when the history was saved
                lens = data[k + "dlen"]
                didx, dold, dnew = data[k + "didx"], data[k + "dold"], data[k + "dnew"]
                off = 0
                for j, n in enumerate(lens):
                    if n >= 0:
                        n = int(n)
                        h.deltas[j] = (np.array(didx[off:off + n], dtype=np.int32),
                                       np.array(dold[off:off + n], dtype=np.float32),
                                       np.array(dnew[off:off + n], dtype=np.float32))
                        off += n
                h.pos = pos
                h.counts = mesh_counts(obj.data)
            _hist[obj.session_uid] = h
            _names[obj.session_uid] = obj.name
    redraw()


def _load_after_enable():
    try:
        if not _hist:
            load_history()
    except Exception:
        traceback.print_exc()
    return None


def start_watchers():
    """Sculpt strokes don't send update events to Python, so a passive modal
    watcher notes the mouse press and flags the object once the stroke is over."""
    try:
        wm = bpy.context.window_manager
        for win in wm.windows:
            ptr = win.as_pointer()
            if ptr in _watchers:
                continue
            area = next((a for a in win.screen.areas if a.type == 'VIEW_3D'), None)
            if area is None:
                continue
            _watchers.add(ptr)  # added first so a failed start isn't retried every tick
            with bpy.context.temp_override(window=win, screen=win.screen, area=area):
                bpy.ops.object_undo_history.watch('INVOKE_DEFAULT')
    except Exception:
        traceback.print_exc()


def tick():
    global _scrub, _settle
    try:
        now = time.monotonic()
        p = prefs()

        if not _stop:
            start_watchers()

        # Baseline for the active object, so its first change can be undone.
        act = active_object()
        if act is not None and tracking(act) and get_hist(act) is None and act.session_uid not in _dirty:
            record(act)

        # Record objects that changed and then went quiet.
        for uid, t in list(_dirty.items()):
            if uid == _press:
                continue  # stroke still in progress
            if now - t >= p.idle_delay:
                obj = get_obj(uid)
                if obj is None:
                    _dirty.pop(uid, None)
                else:
                    record(obj)

        sync_scrub_range()

        # Finish a slider scrub once the mouse has settled.
        if _scrub is not None and now - _scrub["time"] >= 0.25:
            s, _scrub = _scrub, None
            obj = get_obj(s["uid"])
            if obj is not None and obj.mode == 'EDIT':
                restore(obj, s["index"])
        if _settle is not None and now - _settle[1] >= 0.25:
            uid, _settle = _settle[0], None
            obj = get_obj(uid)
            if obj is not None:
                sculpt_refresh(obj)
    except Exception:
        traceback.print_exc()
    return 0.05 if (_scrub or _settle) else 0.1


# ---------------------------------------------------------------------------
# Scrub slider: a whole-number bar from step 1 to the active object's step count.
# Blender sliders have a fixed max, so the property is re-made when the count changes.
# ---------------------------------------------------------------------------

_scrub_max = 0


def _scrub_get(self):
    obj = active_object()
    h = get_hist(obj) if obj else None
    if h is None or not h.mats:
        return 1
    return h.index + 1


def make_scrub_prop(n):
    global _scrub_max
    n = max(2, n)
    if n == _scrub_max:
        return
    _scrub_max = n
    bpy.types.WindowManager.orw_scrub = bpy.props.IntProperty(
        name="Step", description="Drag to move through this object's history",
        min=1, max=n, get=_scrub_get, set=_scrub_set)


def sync_scrub_range():
    obj = active_object()
    h = get_hist(obj) if obj else None
    make_scrub_prop(len(h.mats) if h else 2)


def _scrub_set(self, value):
    global _scrub
    obj = active_object()
    if obj is None or not tracking(obj):
        return
    flush(obj)
    h = get_hist(obj)
    if h is None or len(h.mats) < 2:
        return
    target = max(0, min(int(value) - 1, len(h.mats) - 1))
    if obj.mode == 'EDIT':
        _scrub = {"uid": obj.session_uid, "index": target, "time": time.monotonic()}  # applied in tick()
    elif target != h.index:
        restore(obj, target, live=True)


# ---------------------------------------------------------------------------
# Operators
# ---------------------------------------------------------------------------

class ORW_OT_watch(bpy.types.Operator):
    """Internal: notices when a sculpt or paint stroke finishes"""
    bl_idname = "object_undo_history.watch"
    bl_label = "Object Specific Undo History Stroke Watcher"
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        global _press
        if _stop:
            return {'CANCELLED'}
        # While a stroke runs, the brush operator eats every event, so the first
        # event that reaches us after a press means the stroke has finished.
        if _press is not None:
            _dirty[_press] = time.monotonic()
            _geo.add(_press)
            _press = None
        if event.type in {'LEFTMOUSE', 'PEN'} and event.value == 'PRESS':
            ob = active_object()
            if ob is not None and ob.mode in STROKE_MODES and tracking(ob):
                _press = ob.session_uid
                _names[ob.session_uid] = ob.name
        return {'PASS_THROUGH'}


class ORW_OT_step(bpy.types.Operator):
    """Undo or redo the active object only"""
    bl_idname = "object_undo_history.step"
    bl_label = "Object Undo/Redo"

    direction: bpy.props.IntProperty(default=-1)

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        obj = context.active_object
        if not tracking(obj):
            self.report({'INFO'}, "History is off for this object")
            return {'CANCELLED'}
        flush(obj)
        h = get_hist(obj)
        if h is None:
            self.report({'INFO'}, "No history yet")
            return {'CANCELLED'}
        target = h.index + self.direction
        if target < 0 or target >= len(h.mats):
            self.report({'INFO'}, "Nothing to undo" if self.direction < 0 else "Nothing to redo")
            return {'CANCELLED'}
        msg = restore(obj, target)
        if msg:
            self.report({'WARNING'}, msg)
        return {'FINISHED'}


class ORW_OT_smart(bpy.types.Operator):
    """Undo/redo the selected object; with nothing selected, Blender's normal undo runs"""
    bl_idname = "object_undo_history.smart"
    bl_label = "Smart Undo/Redo"

    direction: bpy.props.IntProperty(default=-1)

    def invoke(self, context, event):
        return self.execute(context)

    def execute(self, context):
        obj = context.active_object
        # PASS_THROUGH hands the key on to Blender's own Ctrl+Z / Ctrl+Shift+Z.
        if obj is None or not tracking(obj):
            return {'PASS_THROUGH'}
        if obj.mode == 'OBJECT' and not obj.select_get():
            return {'PASS_THROUGH'}
        flush(obj)
        h = get_hist(obj)
        if h is None:
            return {'PASS_THROUGH'}
        target = h.index + self.direction
        if target < 0 or target >= len(h.mats):
            return {'PASS_THROUGH'}
        msg = restore(obj, target)
        if msg:
            self.report({'WARNING'}, msg)
            return {'PASS_THROUGH'}
        return {'FINISHED'}


class ORW_OT_clear(bpy.types.Operator):
    """Delete the recorded history (your model is not changed)"""
    bl_idname = "object_undo_history.clear"
    bl_label = "Clear History"

    all_objects: bpy.props.BoolProperty(default=False)

    def execute(self, context):
        if self.all_objects:
            _hist.clear()
            _dirty.clear()
            _geo.clear()
        else:
            obj = context.active_object
            if obj is not None:
                _hist.pop(obj.session_uid, None)
                _dirty.pop(obj.session_uid, None)
        redraw()
        return {'FINISHED'}


class ORW_PT_menu(bpy.types.Panel):
    bl_idname = "ORW_PT_menu"
    bl_label = "Object Specific Undo History"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'

    def draw(self, context):
        col = self.layout.column()
        obj = context.active_object
        if obj is not None:
            col.prop(obj, "orw_track", text="Record this object")
        h = get_hist(obj) if obj else None
        if h is not None:
            col.label(text=f"This object: {h.nbytes() / 1048576:.1f} MB")
        total = sum(x.nbytes() for x in _hist.values()) / 1048576
        col.label(text=f"All objects: {total:.1f} MB")
        col.operator("object_undo_history.clear", text="Clear this object").all_objects = False
        col.operator("object_undo_history.clear", text="Clear all objects").all_objects = True
        p = prefs()
        if p is not _DefaultPrefs:
            col.separator()
            col.prop(p, "max_steps")
            col.prop(p, "idle_delay")
            col.prop(p, "sculpt_refresh")
            col.prop(p, "smart_ctrl_z")
            col.prop(p, "save_history")
            col.prop(p, "topo_max_verts")


def draw_header(self, context):
    obj = context.active_object
    if obj is None:
        return
    if context.area is None or context.area.type != 'VIEW_3D':
        return
    layout = self.layout
    layout.separator(factor=2)
    row = layout.row(align=True)
    h = get_hist(obj)
    n = len(h.mats) if h else 0
    row.operator("object_undo_history.step", text="", icon='LOOP_BACK').direction = -1
    bar = row.row(align=True)
    bar.ui_units_x = prefs().bar_width
    bar.enabled = tracking(obj) and n > 1
    label = f"Step (of {n})" if n else "No history"
    if not tracking(obj):
        label = "Recording off"
    bar.prop(context.window_manager, "orw_scrub", text=label, slider=True)
    row.operator("object_undo_history.step", text="", icon='LOOP_FORWARDS').direction = 1
    row.popover("ORW_PT_menu", text="", icon='DOWNARROW_HLT')


class ORW_Prefs(bpy.types.AddonPreferences):
    bl_idname = __package__

    max_steps: bpy.props.IntProperty(name="Max Steps Per Object", default=200, min=2, max=10000)
    smart_ctrl_z: bpy.props.BoolProperty(
        name="Smart Ctrl+Z", default=True, update=lambda self, ctx: update_keymaps(),
        description="Ctrl+Z undoes the selected object. With nothing selected, Blender's normal undo runs")
    idle_delay: bpy.props.FloatProperty(
        name="Record Delay (s)", default=0.1, min=0.05, max=5.0,
        description="How long to wait after a change before recording it. Nothing is recorded mid-stroke")
    sculpt_refresh: bpy.props.BoolProperty(
        name="Refresh Sculpt Mode", default=True,
        description="Briefly re-enter Sculpt Mode after restoring so the viewport shows the restored shape")
    bar_width: bpy.props.IntProperty(name="Bar Width", default=14, min=4, max=60)
    topo_max_verts: bpy.props.IntProperty(
        name="Extrude Undo Vert Limit", default=100000, min=0, soft_max=1000000,
        description="Edits that add or remove vertices (extrude, subdivide...) stay undoable on meshes up "
                    "to this size. Above it they restart the history, because copying a big mesh causes a pause")
    save_history: bpy.props.BoolProperty(
        name="Save History With File", default=True,
        description="When you save, write the history next to the .blend as yourfile.blend.undohistory "
                    "and load it again when the file is opened")

    def draw(self, context):
        col = self.layout.column()
        for p in ("max_steps", "smart_ctrl_z", "save_history", "topo_max_verts", "idle_delay", "sculpt_refresh", "bar_width"):
            col.prop(self, p)
        col.label(text="Ctrl+Alt+Z / Ctrl+Alt+Shift+Z always undo/redo the object only.")


# ---------------------------------------------------------------------------
# Register
# ---------------------------------------------------------------------------

def update_keymaps():
    on = bool(prefs().smart_ctrl_z)
    for _km, kmi in _keymaps:
        if kmi.idname == "object_undo_history.smart":
            kmi.active = on


classes = (ORW_OT_watch, ORW_OT_step, ORW_OT_smart, ORW_OT_clear, ORW_PT_menu, ORW_Prefs)
_keymaps = []


def register():
    global _stop
    _stop = False
    _watchers.clear()
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Object.orw_track = bpy.props.BoolProperty(
        name="Record History", default=True, description="Record per-object history for this object")
    global _scrub_max
    _scrub_max = 0
    make_scrub_prop(2)
    bpy.types.VIEW3D_MT_editor_menus.append(draw_header)

    bpy.app.handlers.depsgraph_update_post.append(on_depsgraph)
    bpy.app.handlers.load_post.append(on_load)
    bpy.app.handlers.save_pre.append(on_save_pre)
    bpy.app.handlers.frame_change_pre.append(on_frame_pre)
    bpy.app.handlers.frame_change_post.append(on_frame_post)
    bpy.app.handlers.save_post.append(on_save_post)
    bpy.app.timers.register(_load_after_enable, first_interval=0.2)
    if not bpy.app.timers.is_registered(tick):
        bpy.app.timers.register(tick, first_interval=0.5, persistent=True)

    kc = bpy.context.window_manager.keyconfigs.addon
    if kc:
        km = kc.keymaps.new(name="3D View", space_type='VIEW_3D')
        kmi = km.keymap_items.new("object_undo_history.step", 'Z', 'PRESS', ctrl=True, alt=True)
        kmi.properties.direction = -1
        _keymaps.append((km, kmi))
        kmi = km.keymap_items.new("object_undo_history.step", 'Z', 'PRESS', ctrl=True, alt=True, shift=True)
        kmi.properties.direction = 1
        _keymaps.append((km, kmi))
        kmi = km.keymap_items.new("object_undo_history.smart", 'Z', 'PRESS', ctrl=True)
        kmi.properties.direction = -1
        _keymaps.append((km, kmi))
        kmi = km.keymap_items.new("object_undo_history.smart", 'Z', 'PRESS', ctrl=True, shift=True)
        kmi.properties.direction = 1
        _keymaps.append((km, kmi))
        update_keymaps()


def unregister():
    global _stop
    _stop = True
    _watchers.clear()
    for km, kmi in _keymaps:
        try:
            km.keymap_items.remove(kmi)
        except Exception:
            pass
    _keymaps.clear()
    if bpy.app.timers.is_registered(tick):
        bpy.app.timers.unregister(tick)
    for lst, fn in ((bpy.app.handlers.depsgraph_update_post, on_depsgraph),
                    (bpy.app.handlers.load_post, on_load),
                    (bpy.app.handlers.save_pre, on_save_pre),
                    (bpy.app.handlers.frame_change_pre, on_frame_pre),
                    (bpy.app.handlers.frame_change_post, on_frame_post),
                    (bpy.app.handlers.save_post, on_save_post)):
        if fn in lst:
            lst.remove(fn)
    bpy.types.VIEW3D_MT_editor_menus.remove(draw_header)
    del bpy.types.WindowManager.orw_scrub
    del bpy.types.Object.orw_track
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
    _hist.clear()
    _names.clear()
    _dirty.clear()
