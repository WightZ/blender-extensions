# Object Specific Undo History: per-object undo history with a scrub bar in the 3D viewport header.
# Phase 1: transforms + mesh vertex positions, stored as deltas.

import json
import os
import time
import traceback

import bpy
import numpy as np
from bpy.app.handlers import persistent
from mathutils import Matrix

# ---------------------------------------------------------------------------
# Storage (RAM only, cleared on file load)
# ---------------------------------------------------------------------------

class History:
    """Steps are stored as small "what changed" deltas, not full mesh copies.
    mats[i]   = object matrix at step i
    deltas[i] = (vert indices, old positions, new positions) going from step i-1 to i
    pos       = full vertex positions at the current step (one copy per object)"""
    __slots__ = ("mats", "deltas", "index", "pos")

    def __init__(self):
        self.mats = []
        self.deltas = []
        self.index = -1
        self.pos = None

    def reset(self, m, pos):
        self.mats = [m]
        self.deltas = [None]
        self.index = 0
        self.pos = pos

    def nbytes(self):
        n = self.pos.nbytes if self.pos is not None else 0
        for d in self.deltas:
            if d is not None:
                n += d[0].nbytes + d[1].nbytes + d[2].nbytes
        return n


_hist = {}       # session_uid -> History
_names = {}      # session_uid -> last known object name
_dirty = {}      # session_uid -> time of last change
_scrub = None    # dict for pending slider scrubs
_settle = None   # (uid, time) sculpt refresh waiting for scrubbing to stop
_press = None    # uid of object whose paint/sculpt stroke is in progress
_watchers = set()  # window pointers with a running stroke watcher
_stop = False

STROKE_MODES = {'SCULPT', 'VERTEX_PAINT', 'WEIGHT_PAINT', 'TEXTURE_PAINT', 'SCULPT_CURVES'}


class _DefaultPrefs:
    max_steps = 200
    smart_ctrl_z = True
    save_history = True
    idle_delay = 0.1
    sculpt_refresh = True
    bar_width = 14


def prefs():
    try:
        return bpy.context.preferences.addons[__package__].preferences
    except Exception:
        return _DefaultPrefs


def tracking(obj):
    return obj is not None and getattr(obj, "orw_track", True)


def get_obj(uid):
    name = _names.get(uid)
    obj = bpy.data.objects.get(name) if name else None
    if obj is not None and obj.session_uid == uid:
        return obj
    for ob in bpy.data.objects:  # renamed?
        if ob.session_uid == uid:
            _names[uid] = ob.name
            return ob
    return None


def get_hist(obj):
    """Find this object's history, re-linking it if Blender's undo gave the object a new id."""
    uid = obj.session_uid
    h = _hist.get(uid)
    if h is not None:
        return h
    for old_uid, name in list(_names.items()):
        if name == obj.name and old_uid in _hist and get_obj(old_uid) is None:
            _hist[uid] = _hist.pop(old_uid)
            _names.pop(old_uid, None)
            _names[uid] = obj.name
            if old_uid in _dirty:
                _dirty[uid] = _dirty.pop(old_uid)
            return _hist[uid]
    return None


def active_object():
    try:
        ob = bpy.context.view_layer.objects.active
        if ob is not None:
            return ob
    except Exception:
        pass
    try:
        return bpy.context.window_manager.windows[0].view_layer.objects.active
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Capture / record / restore
# ---------------------------------------------------------------------------

def capture(obj):
    m = tuple(v for row in obj.matrix_basis for v in row)
    pos = None
    if obj.type == 'MESH':
        if obj.mode == 'EDIT':
            obj.update_from_editmode()
        me = obj.data
        pos = np.empty(len(me.vertices) * 3, dtype=np.float32)
        me.vertices.foreach_get("co", pos)
        pos = pos.reshape(-1, 3)
    return m, pos


def record(obj):
    """Add a new step if the object changed since its current step. Returns True if added."""
    if not tracking(obj):
        return False
    uid = obj.session_uid
    h = get_hist(obj)
    _names[uid] = obj.name
    _dirty.pop(uid, None)
    m, pos = capture(obj)

    if h is None or not h.mats:
        h = _hist[uid] = History()
        h.reset(m, pos)
        redraw()
        return True

    if (pos is None) != (h.pos is None) or (pos is not None and pos.shape != h.pos.shape):
        h.reset(m, pos)  # vertex count changed (remesh etc.): old shapes can't be restored
        redraw()
        return True

    delta = None
    if pos is not None:
        changed = np.flatnonzero((h.pos != pos).any(axis=1)).astype(np.int32)
        if changed.size:
            delta = (changed, h.pos[changed], pos[changed])
            h.pos[changed] = pos[changed]

    cm = h.mats[h.index]
    if delta is None and cm == m:
        return False
    if cm == m:
        m = cm  # share data with previous step

    del h.mats[h.index + 1:]    # a new change replaces the redo steps
    del h.deltas[h.index + 1:]
    h.mats.append(m)
    h.deltas.append(delta)
    over = len(h.mats) - max(2, prefs().max_steps)
    if over > 0:
        del h.mats[:over]
        del h.deltas[:over]
        h.deltas[0] = None
    h.index = len(h.mats) - 1
    redraw()
    return True


def flush(obj):
    """Record any pending change right now (used before undo/scrub)."""
    if obj is not None and (obj.session_uid in _dirty or get_hist(obj) is None):
        record(obj)


def view3d_override():
    wm = bpy.context.window_manager
    for win in wm.windows:
        for area in win.screen.areas:
            if area.type == 'VIEW_3D':
                region = next((r for r in area.regions if r.type == 'WINDOW'), None)
                return {"window": win, "area": area, "region": region}
    return {}


def mode_set(mode):
    with bpy.context.temp_override(**view3d_override()):
        bpy.ops.object.mode_set(mode=mode)


def sculpt_refresh(obj):
    """Sculpt mode keeps its own copy of the mesh, so re-enter the mode to show restored data."""
    if obj.mode == 'SCULPT' and active_object() == obj:
        mode_set('OBJECT')
        mode_set('SCULPT')


def restore(obj, index, live=False):
    """Jump obj to a history step. live=True is the cheap path used while scrubbing."""
    global _settle
    h = get_hist(obj)
    if h is None or not h.mats:
        return "No history"
    index = max(0, min(index, len(h.mats) - 1))
    mesh = h.pos is not None and obj.type == 'MESH'
    if mesh and len(obj.data.vertices) != len(h.pos):
        return "Mesh topology changed, can't restore"
    if mesh and obj.mode == 'EDIT' and live:
        return None  # edit mode is applied once scrubbing stops

    m = h.mats[index]
    obj.matrix_basis = Matrix((m[0:4], m[4:8], m[8:12], m[12:16]))

    if mesh and index != h.index:
        pos = h.pos
        i = h.index
        while i < index:          # forwards: apply "new" values
            i += 1
            d = h.deltas[i]
            if d is not None:
                pos[d[0]] = d[2]
        while i > index:          # backwards: apply "old" values
            d = h.deltas[i]
            if d is not None:
                pos[d[0]] = d[1]
            i -= 1
        me = obj.data
        if obj.mode == 'EDIT':
            mode_set('OBJECT')
            me.vertices.foreach_set("co", pos.ravel())
            me.update()
            mode_set('EDIT')
        else:
            me.vertices.foreach_set("co", pos.ravel())
            me.update()
            if obj.mode == 'SCULPT' and prefs().sculpt_refresh:
                if live:
                    _settle = (obj.session_uid, time.monotonic())
                else:
                    sculpt_refresh(obj)

    h.index = index
    _dirty.pop(obj.session_uid, None)
    redraw()
    return None


def redraw():
    try:
        for win in bpy.context.window_manager.windows:
            for area in win.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Change detection (kept tiny so it adds no lag while brushing)
# ---------------------------------------------------------------------------

@persistent
def on_depsgraph(scene, depsgraph):
    try:
        scr = bpy.context.screen
        if scr is not None and scr.is_animation_playing:
            return
    except Exception:
        pass
    now = time.monotonic()
    act = active_object()
    for u in depsgraph.updates:
        idb = u.id
        if isinstance(idb, bpy.types.Object):
            if not (u.is_updated_geometry or u.is_updated_transform):
                continue
            ob = idb.original
            if ob is act or ob.select_get():
                _dirty[ob.session_uid] = now
                _names[ob.session_uid] = ob.name
        elif isinstance(idb, bpy.types.Mesh) and u.is_updated_geometry:
            if act is not None and act.data is not None and act.data.original == idb.original:
                _dirty[act.session_uid] = now
                _names[act.session_uid] = act.name


@persistent
def on_load(*_args):
    global _scrub, _settle, _press
    _hist.clear()
    _names.clear()
    _dirty.clear()
    _watchers.clear()  # modal watchers die on file load; tick() restarts them
    _scrub = None
    _settle = None
    _press = None
    try:
        load_history()
    except Exception:
        traceback.print_exc()


# ---------------------------------------------------------------------------
# Saving history next to the .blend (yourfile.blend.undohistory)
# ---------------------------------------------------------------------------

SIDECAR_EXT = ".undohistory"
SIDECAR_VERSION = 1


def sidecar_path():
    fp = bpy.data.filepath
    return fp + SIDECAR_EXT if fp else None


@persistent
def on_save_pre(*_args):
    # Record anything still waiting so the saved history matches the saved file.
    for uid in list(_dirty):
        obj = get_obj(uid)
        if obj is not None:
            try:
                record(obj)
            except Exception:
                traceback.print_exc()


@persistent
def on_save_post(*_args):
    if not prefs().save_history:
        return
    try:
        save_history()
    except Exception:
        traceback.print_exc()


def save_history():
    path = sidecar_path()
    if not path:
        return
    arrays = {}
    meta = {"version": SIDECAR_VERSION, "objects": []}
    i = 0
    for uid, h in _hist.items():
        obj = get_obj(uid)
        if obj is None or not h.mats:
            continue
        k = f"o{i}_"
        arrays[k + "mats"] = np.array(h.mats, dtype=np.float64)
        has_pos = h.pos is not None
        if has_pos:
            arrays[k + "pos"] = h.pos
            lens = np.array([-1 if d is None else len(d[0]) for d in h.deltas], dtype=np.int64)
            parts = [d for d in h.deltas if d is not None]
            arrays[k + "dlen"] = lens
            arrays[k + "didx"] = np.concatenate([d[0] for d in parts]) if parts else np.zeros(0, np.int32)
            arrays[k + "dold"] = np.concatenate([d[1] for d in parts]) if parts else np.zeros((0, 3), np.float32)
            arrays[k + "dnew"] = np.concatenate([d[2] for d in parts]) if parts else np.zeros((0, 3), np.float32)
        meta["objects"].append({"key": k, "name": obj.name, "index": h.index, "has_pos": has_pos})
        i += 1
    if not meta["objects"]:
        if os.path.exists(path):
            os.remove(path)  # nothing to keep, don't leave a stale history behind
        return
    arrays["meta"] = np.frombuffer(json.dumps(meta).encode("utf-8"), dtype=np.uint8)
    tmp = path + ".tmp"
    with open(tmp, "wb") as f:
        np.savez(f, **arrays)
    os.replace(tmp, path)  # only swap in a fully written file


def load_history():
    path = sidecar_path()
    if not path or not os.path.exists(path):
        return
    with np.load(path, allow_pickle=False) as data:
        meta = json.loads(bytes(data["meta"]).decode("utf-8"))
        if meta.get("version") != SIDECAR_VERSION:
            return
        for o in meta["objects"]:
            obj = bpy.data.objects.get(o["name"])
            if obj is None:
                continue
            k = o["key"]
            mats = [tuple(float(v) for v in row) for row in data[k + "mats"]]
            h = History()
            h.mats = mats
            h.index = min(int(o["index"]), len(mats) - 1)
            h.deltas = [None] * len(mats)
            if o["has_pos"]:
                if obj.type != 'MESH':
                    continue
                pos = np.array(data[k + "pos"], dtype=np.float32)
                if len(obj.data.vertices) != len(pos):
                    continue  # mesh changed outside the add-on, history no longer fits
                cur = np.empty(len(pos) * 3, dtype=np.float32)
                obj.data.vertices.foreach_get("co", cur)
                if not np.array_equal(cur.reshape(-1, 3), pos):
                    continue  # shape differs from when the history was saved
                lens = data[k + "dlen"]
                didx, dold, dnew = data[k + "didx"], data[k + "dold"], data[k + "dnew"]
                off = 0
                for j, n in enumerate(lens):
                    if n >= 0:
                        n = int(n)
                        h.deltas[j] = (np.array(didx[off:off + n], dtype=np.int32),
                                       np.array(dold[off:off + n], dtype=np.float32),
                                       np.array(dnew[off:off + n], dtype=np.float32))
                        off += n
                h.pos = pos
            _hist[obj.session_uid] = h
            _names[obj.session_uid] = obj.name
    redraw()


def _load_after_enable():
    try:
        if not _hist:
            load_history()
    except Exception:
        traceback.print_exc()
    return None


def start_watchers():
    """Sculpt strokes don't send update events to Python, so a passive modal
    watcher notes the mouse press and flags the object once the stroke is over."""
    try:
        wm = bpy.context.window_manager
        for win in wm.windows:
            ptr = win.as_pointer()
            if ptr in _watchers:
                continue
            area = next((a for a in win.screen.areas if a.type == 'VIEW_3D'), None)
            if area is None:
                continue
            _watchers.add(ptr)  # added first so a failed start isn't retried every tick
            with bpy.context.temp_override(window=win, screen=win.screen, area=area):
                bpy.ops.object_undo_history.watch('INVOKE_DEFAULT')
    except Exception:
        traceback.print_exc()


def tick():
    global _scrub, _settle
    try:
        now = time.monotonic()
        p = prefs()

        if not _stop:
            start_watchers()

        # Baseline for the active object, so its first change can be undone.
        act = active_object()
        if act is not None and tracking(act) and get_hist(act) is None and act.session_uid not in _dirty:
            record(act)

        # Record objects that changed and then went quiet.
        for uid, t in list(_dirty.items()):
            if uid == _press:
                continue  # stroke still in progress
            if now - t >= p.idle_delay:
                obj = get_obj(uid)
                if obj is None:
                    _dirty.pop(uid, None)
                else:
                    record(obj)

        sync_scrub_range()

        # Finish a slider scrub once the mouse has settled.
        if _scrub is not None and now - _scrub["time"] >= 0.25:
            s, _scrub = _scrub, None
            obj = get_obj(s["uid"])
            if obj is not None and obj.mode == 'EDIT':
                restore(obj, s["index"])
        if _settle is not None and now - _settle[1] >= 0.25:
            uid, _settle = _settle[0], None
            obj = get_obj(uid)
            if obj is not None:
                sculpt_refresh(obj)
    except Exception:
        traceback.print_exc()
    return 0.05 if (_scrub or _settle) else 0.1


# ---------------------------------------------------------------------------
# Scrub slider: a whole-number bar from step 1 to the active object's step count.
# Blender sliders have a fixed max, so the property is re-made when the count changes.
# ---------------------------------------------------------------------------

_scrub_max = 0


def _scrub_get(self):
    obj = active_object()
    h = get_hist(obj) if obj else None
    if h is None or not h.mats:
        return 1
    return h.index + 1


def make_scrub_prop(n):
    global _scrub_max
    n = max(2, n)
    if n == _scrub_max:
        return
    _scrub_max = n
    bpy.types.WindowManager.orw_scrub = bpy.props.IntProperty(
        name="Step", description="Drag to move through this object's history",
        min=1, max=n, get=_scrub_get, set=_scrub_set)


def sync_scrub_range():
    obj = active_object()
    h = get_hist(obj) if obj else None
    make_scrub_prop(len(h.mats) if h else 2)


def _scrub_set(self, value):
    global _scrub
    obj = active_object()
    if obj is None or not tracking(obj):
        return
    flush(obj)
    h = get_hist(obj)
    if h is None or len(h.mats) < 2:
        return
    target = max(0, min(int(value) - 1, len(h.mats) - 1))
    if obj.mode == 'EDIT':
        _scrub = {"uid": obj.session_uid, "index": target, "time": time.monotonic()}  # applied in tick()
    elif target != h.index:
        restore(obj, target, live=True)


# ---------------------------------------------------------------------------
# Operators
# ---------------------------------------------------------------------------

class ORW_OT_watch(bpy.types.Operator):
    """Internal: notices when a sculpt or paint stroke finishes"""
    bl_idname = "object_undo_history.watch"
    bl_label = "Object Specific Undo History Stroke Watcher"
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        global _press
        if _stop:
            return {'CANCELLED'}
        # While a stroke runs, the brush operator eats every event, so the first
        # event that reaches us after a press means the stroke has finished.
        if _press is not None:
            _dirty[_press] = time.monotonic()
            _press = None
        if event.type in {'LEFTMOUSE', 'PEN'} and event.value == 'PRESS':
            ob = active_object()
            if ob is not None and ob.mode in STROKE_MODES and tracking(ob):
                _press = ob.session_uid
                _names[ob.session_uid] = ob.name
        return {'PASS_THROUGH'}


class ORW_OT_step(bpy.types.Operator):
    """Undo or redo the active object only"""
    bl_idname = "object_undo_history.step"
    bl_label = "Object Undo/Redo"

    direction: bpy.props.IntProperty(default=-1)

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        obj = context.active_object
        if not tracking(obj):
            self.report({'INFO'}, "History is off for this object")
            return {'CANCELLED'}
        flush(obj)
        h = get_hist(obj)
        if h is None:
            self.report({'INFO'}, "No history yet")
            return {'CANCELLED'}
        target = h.index + self.direction
        if target < 0 or target >= len(h.mats):
            self.report({'INFO'}, "Nothing to undo" if self.direction < 0 else "Nothing to redo")
            return {'CANCELLED'}
        msg = restore(obj, target)
        if msg:
            self.report({'WARNING'}, msg)
        return {'FINISHED'}


class ORW_OT_smart(bpy.types.Operator):
    """Undo/redo the selected object; with nothing selected, Blender's normal undo runs"""
    bl_idname = "object_undo_history.smart"
    bl_label = "Smart Undo/Redo"

    direction: bpy.props.IntProperty(default=-1)

    def invoke(self, context, event):
        return self.execute(context)

    def execute(self, context):
        obj = context.active_object
        # PASS_THROUGH hands the key on to Blender's own Ctrl+Z / Ctrl+Shift+Z.
        if obj is None or not tracking(obj):
            return {'PASS_THROUGH'}
        if obj.mode == 'OBJECT' and not obj.select_get():
            return {'PASS_THROUGH'}
        flush(obj)
        h = get_hist(obj)
        if h is None:
            return {'PASS_THROUGH'}
        target = h.index + self.direction
        if target < 0 or target >= len(h.mats):
            return {'PASS_THROUGH'}
        msg = restore(obj, target)
        if msg:
            self.report({'WARNING'}, msg)
            return {'PASS_THROUGH'}
        return {'FINISHED'}


class ORW_OT_clear(bpy.types.Operator):
    """Delete the recorded history (your model is not changed)"""
    bl_idname = "object_undo_history.clear"
    bl_label = "Clear History"

    all_objects: bpy.props.BoolProperty(default=False)

    def execute(self, context):
        if self.all_objects:
            _hist.clear()
            _dirty.clear()
        else:
            obj = context.active_object
            if obj is not None:
                _hist.pop(obj.session_uid, None)
                _dirty.pop(obj.session_uid, None)
        redraw()
        return {'FINISHED'}


class ORW_PT_menu(bpy.types.Panel):
    bl_idname = "ORW_PT_menu"
    bl_label = "Object Specific Undo History"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'

    def draw(self, context):
        col = self.layout.column()
        obj = context.active_object
        if obj is not None:
            col.prop(obj, "orw_track", text="Record this object")
        h = get_hist(obj) if obj else None
        if h is not None:
            col.label(text=f"This object: {h.nbytes() / 1048576:.1f} MB")
        total = sum(x.nbytes() for x in _hist.values()) / 1048576
        col.label(text=f"All objects: {total:.1f} MB")
        col.operator("object_undo_history.clear", text="Clear this object").all_objects = False
        col.operator("object_undo_history.clear", text="Clear all objects").all_objects = True
        p = prefs()
        if p is not _DefaultPrefs:
            col.separator()
            col.prop(p, "max_steps")
            col.prop(p, "idle_delay")
            col.prop(p, "sculpt_refresh")
            col.prop(p, "smart_ctrl_z")
            col.prop(p, "save_history")


def draw_header(self, context):
    obj = context.active_object
    if obj is None:
        return
    if context.area is None or context.area.type != 'VIEW_3D':
        return
    layout = self.layout
    layout.separator(factor=2)
    row = layout.row(align=True)
    h = get_hist(obj)
    n = len(h.mats) if h else 0
    row.operator("object_undo_history.step", text="", icon='LOOP_BACK').direction = -1
    bar = row.row(align=True)
    bar.ui_units_x = prefs().bar_width
    bar.enabled = tracking(obj) and n > 1
    label = f"Step (of {n})" if n else "No history"
    if not tracking(obj):
        label = "Recording off"
    bar.prop(context.window_manager, "orw_scrub", text=label, slider=True)
    row.operator("object_undo_history.step", text="", icon='LOOP_FORWARDS').direction = 1
    row.popover("ORW_PT_menu", text="", icon='DOWNARROW_HLT')


class ORW_Prefs(bpy.types.AddonPreferences):
    bl_idname = __package__

    max_steps: bpy.props.IntProperty(name="Max Steps Per Object", default=200, min=2, max=10000)
    smart_ctrl_z: bpy.props.BoolProperty(
        name="Smart Ctrl+Z", default=True, update=lambda self, ctx: update_keymaps(),
        description="Ctrl+Z undoes the selected object. With nothing selected, Blender's normal undo runs")
    idle_delay: bpy.props.FloatProperty(
        name="Record Delay (s)", default=0.1, min=0.05, max=5.0,
        description="How long to wait after a change before recording it. Nothing is recorded mid-stroke")
    sculpt_refresh: bpy.props.BoolProperty(
        name="Refresh Sculpt Mode", default=True,
        description="Briefly re-enter Sculpt Mode after restoring so the viewport shows the restored shape")
    bar_width: bpy.props.IntProperty(name="Bar Width", default=14, min=4, max=60)
    save_history: bpy.props.BoolProperty(
        name="Save History With File", default=True,
        description="When you save, write the history next to the .blend as yourfile.blend.undohistory "
                    "and load it again when the file is opened")

    def draw(self, context):
        col = self.layout.column()
        for p in ("max_steps", "smart_ctrl_z", "save_history", "idle_delay", "sculpt_refresh", "bar_width"):
            col.prop(self, p)
        col.label(text="Ctrl+Alt+Z / Ctrl+Alt+Shift+Z always undo/redo the object only.")


# ---------------------------------------------------------------------------
# Register
# ---------------------------------------------------------------------------

def update_keymaps():
    on = bool(prefs().smart_ctrl_z)
    for _km, kmi in _keymaps:
        if kmi.idname == "object_undo_history.smart":
            kmi.active = on


classes = (ORW_OT_watch, ORW_OT_step, ORW_OT_smart, ORW_OT_clear, ORW_PT_menu, ORW_Prefs)
_keymaps = []


def register():
    global _stop
    _stop = False
    _watchers.clear()
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Object.orw_track = bpy.props.BoolProperty(
        name="Record History", default=True, description="Record per-object history for this object")
    global _scrub_max
    _scrub_max = 0
    make_scrub_prop(2)
    bpy.types.VIEW3D_MT_editor_menus.append(draw_header)

    bpy.app.handlers.depsgraph_update_post.append(on_depsgraph)
    bpy.app.handlers.load_post.append(on_load)
    bpy.app.handlers.save_pre.append(on_save_pre)
    bpy.app.handlers.save_post.append(on_save_post)
    bpy.app.timers.register(_load_after_enable, first_interval=0.2)
    if not bpy.app.timers.is_registered(tick):
        bpy.app.timers.register(tick, first_interval=0.5, persistent=True)

    kc = bpy.context.window_manager.keyconfigs.addon
    if kc:
        km = kc.keymaps.new(name="3D View", space_type='VIEW_3D')
        kmi = km.keymap_items.new("object_undo_history.step", 'Z', 'PRESS', ctrl=True, alt=True)
        kmi.properties.direction = -1
        _keymaps.append((km, kmi))
        kmi = km.keymap_items.new("object_undo_history.step", 'Z', 'PRESS', ctrl=True, alt=True, shift=True)
        kmi.properties.direction = 1
        _keymaps.append((km, kmi))
        kmi = km.keymap_items.new("object_undo_history.smart", 'Z', 'PRESS', ctrl=True)
        kmi.properties.direction = -1
        _keymaps.append((km, kmi))
        kmi = km.keymap_items.new("object_undo_history.smart", 'Z', 'PRESS', ctrl=True, shift=True)
        kmi.properties.direction = 1
        _keymaps.append((km, kmi))
        update_keymaps()


def unregister():
    global _stop
    _stop = True
    _watchers.clear()
    for km, kmi in _keymaps:
        try:
            km.keymap_items.remove(kmi)
        except Exception:
            pass
    _keymaps.clear()
    if bpy.app.timers.is_registered(tick):
        bpy.app.timers.unregister(tick)
    for lst, fn in ((bpy.app.handlers.depsgraph_update_post, on_depsgraph),
                    (bpy.app.handlers.load_post, on_load),
                    (bpy.app.handlers.save_pre, on_save_pre),
                    (bpy.app.handlers.save_post, on_save_post)):
        if fn in lst:
            lst.remove(fn)
    bpy.types.VIEW3D_MT_editor_menus.remove(draw_header)
    del bpy.types.WindowManager.orw_scrub
    del bpy.types.Object.orw_track
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
    _hist.clear()
    _names.clear()
    _dirty.clear()
